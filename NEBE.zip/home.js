 const sidebar = document.getElementById("side")
  const sidebr = document.getElementById("sidde")

sidebar.addEventListener("click" ,showsidebar)
sidebr.addEventListener("click" ,hidesidebar)

function showsidebar(){
 const sideb = document.querySelector(".side")

sideb.style.display ='flex'
}
function hidesidebar(){
 const side = document.querySelector(".side")
 side.style.display ='none'
 
}