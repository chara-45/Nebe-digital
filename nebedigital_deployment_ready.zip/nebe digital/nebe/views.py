from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password, make_password
from django.db import IntegrityError, transaction
from django.shortcuts import get_object_or_404, redirect, render

from .models import News, Voters, Part, vote


@login_required
def home(request):
    news = News.objects.all().order_by("-created_at")
    return render(request, "home/home.html", {"news": news})


def signup(request):
    if request.method == "POST":
        username = request.POST.get("name", "").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "")

        if not username or not password:
            return render(request, "home/signup.html", {
                "error": "Username and password are required."
            })

        if User.objects.filter(username=username).exists():
            return render(request, "home/signup.html", {
                "error": "That username already exists."
            })

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
        )
        login(request, user)
        return redirect("home")

    return render(request, "home/signup.html")


def user_login(request):
    if request.method == "POST":
        username = request.POST.get("name", "").strip()
        password = request.POST.get("password", "")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("home")

        return render(request, "home/login.html", {
            "error": "Invalid username or password."
        })

    return render(request, "home/login.html")


@login_required
def rigester(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        national_id = request.POST.get("national_id", "").strip()
        password = request.POST.get("password", "")

        if not name or not national_id or not password:
            messages.error(request, "Please fill in all fields.")
            return render(request, "home/registre.html")

        if Voters.objects.filter(national_id=national_id).exists():
            messages.error(request, "This national ID is already registered.")
            return render(request, "home/registre.html")

        Voters.objects.create(
            name=name,
            national_id=national_id,
            password=make_password(password),
        )

        messages.success(
            request,
            "Registered successfully. You can vote when voting is open."
        )
        return redirect("rigester")

    return render(request, "home/registre.html")


def voter_login(request):
    if request.method == "POST":
        national_id = request.POST.get("national_id", "").strip()
        password = request.POST.get("password", "")

        voter = None

        # Supports the old database: existing passwords were stored as plain
        # text. A successful legacy login is immediately upgraded to a hash.
        candidates = Voters.objects.filter(national_id=national_id).order_by("id")
        for candidate in candidates:
            if check_password(password, candidate.password):
                voter = candidate
                break

            if candidate.password == password:
                candidate.password = make_password(password)
                candidate.save(update_fields=["password"])
                voter = candidate
                break

        if voter is None:
            return render(request, "home/login_vote.html", {
                "error": "Invalid national ID or password."
            })

        request.session.flush()
        request.session["voter_id"] = voter.id

        return redirect("vote")

    return render(request, "home/login_vote.html")


def voter_view(request):
    voter_id = request.session.get("voter_id")

    if not voter_id:
        return redirect("login_vote")

    voter = get_object_or_404(Voters, id=voter_id)
    already_voted = vote.objects.filter(voter=voter).exists()

    if request.method == "POST":
        if already_voted:
            messages.error(request, "You have already voted.")
            return redirect("vote")

        part_id = request.POST.get("part")

        if not part_id:
            messages.error(request, "Please select a party.")
            return redirect("vote")

        part = get_object_or_404(Part, id=part_id)

        try:
            with transaction.atomic():
                vote.objects.create(voter=voter, part=part)
        except IntegrityError:
            messages.error(request, "A vote has already been recorded for this voter.")
            return redirect("vote")

        messages.success(request, "Your vote has been recorded successfully.")
        return redirect("vote_success")

    parts = Part.objects.all().order_by("id")

    return render(
        request,
        "home/vote.html",
        {
            "voter": voter,
            "part": parts,
            "already_voted": already_voted,
        },
    )


def vote_success(request):
    voter_id = request.session.get("voter_id")
    if not voter_id:
        return redirect("login_vote")

    return render(request, "home/verfid.html")


def voter_logout(request):
    request.session.flush()
    return redirect("login_vote")
