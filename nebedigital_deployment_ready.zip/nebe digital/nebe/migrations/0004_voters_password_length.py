from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("nebe", "0003_part_vote"),
    ]

    operations = [
        migrations.AlterField(
            model_name="voters",
            name="password",
            field=models.CharField(max_length=128),
        ),
    ]
