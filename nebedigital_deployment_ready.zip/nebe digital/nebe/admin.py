from django.contrib import admin
from .models import News,Voters,Part,vote

admin.site.register(News)
admin.site.register(Voters)
admin.site.register(Part)
admin.site.register(vote)

# Register your models here.
