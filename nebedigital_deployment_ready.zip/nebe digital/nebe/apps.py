from django.apps import AppConfig


class NebeConfig(AppConfig):
    name = 'nebe'
