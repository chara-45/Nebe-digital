from django.urls import path

from .views import (
    signup,
    home,
    user_login,
    rigester,
    voter_view,
    voter_login,
    voter_logout,
    vote_success,
)

urlpatterns = [
    path("", home, name="home"),
    path("signup/", signup, name="sign up"),
    path("login/", user_login, name="log in"),
    path("rigester/", rigester, name="rigester"),
    path("vote/", voter_view, name="vote"),
    path("voter_login/", voter_login, name="login_vote"),
    path("vote/success/", vote_success, name="vote_success"),
    path("voter_logout/", voter_logout, name="voter_logout"),
]
