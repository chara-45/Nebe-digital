from django.db import models


class News(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    image = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class Voters(models.Model):
    name = models.CharField(max_length=100)
    national_id = models.CharField(max_length=100)
    # 128 chars is enough for Django password hashes.
    password = models.CharField(max_length=128)

    def __str__(self):
        return f"{self.name} ({self.national_id})"


class Part(models.Model):
    name = models.CharField(max_length=100)
    party = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class vote(models.Model):
    voter = models.OneToOneField(
        Voters,
        on_delete=models.CASCADE
    )
    part = models.ForeignKey(
        Part,
        on_delete=models.CASCADE
    )

    def __str__(self):
        return f"{self.voter.name} -> {self.part.name}"
